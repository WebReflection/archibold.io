# pyscript/micropython

Install static-handler (needed to have special headers) and run it via:

```sh
npm install
npm run server
```

Visit [http://localhost:8080/](http://localhost:8080/) and open devtools console (inspect or Ctrl+Shift+i) and see:

```
LEAKED SCOPE

Array(6) ... < expand this

OK

LEAKED SCOPE

Array(9) ... < expand this

OK
```

Some observation:

    * there is no way to intercept on *core* side who is invoking that, passing along what looks like the `proxy_js_ref` global reference in [micropython.mjs](./micropython.mjs) as function context. I think there's some *WASM*ish going weirdly wrong.

    * the `proxy_js_ref` also keeps growing but that *might* be due to the fact `_ref` or any `"_ref" in obj` returns false ... but that's another story: see https://github.com/pyodide/pyodide/pull/3963#issuecomment-1609577770 and how Pyodide fixed this dance (rightly so).

    * once intercepted with a very ugly dance that won't slow down every single forwarded invoke, changing that to just the current global context seems to fix all the issue but the leaked context worries me.
