from xworker import xworker

xworker.window.console.log('OK')

# repeated to be sure this can be used twice
# as it was not always the case while debugging
# and before latest changes happened.
xworker.window.console.log('OK')
