// ⚠️ AUTOMATICALLY GENERATED - DO NOT CHANGE
const CHANNEL = '1ac71136-6b6e-4427-96f9-571519ee49f7';

const MAIN = 'M' + CHANNEL;
const THREAD = 'T' + CHANNEL;

// encodeURIComponent('onmessage=({data:b})=>(Atomics.wait(b,0),postMessage(0))')

var waitAsyncFallback = buffer => ({
  value: new Promise(onmessage => {
    let w = new Worker('data:application/javascript,onmessage%3D(%7Bdata%3Ab%7D)%3D%3E(Atomics.wait(b%2C0)%2CpostMessage(0))');
    w.onmessage = onmessage;
    w.postMessage(buffer);
  })
});

/*! (c) Andrea Giammarchi - ISC */


// just minifier friendly for Blob Workers' cases
const {Int32Array, Map: Map$1, SharedArrayBuffer: SharedArrayBuffer$1, Uint16Array} = globalThis;

// common constants / utilities for repeated operations
const {BYTES_PER_ELEMENT: I32_BYTES} = Int32Array;
const {BYTES_PER_ELEMENT: UI16_BYTES} = Uint16Array;

const {isArray: isArray$2} = Array;
const {notify, wait, waitAsync} = Atomics;
const {fromCharCode} = String;

// automatically uses sync wait (worker -> main)
// or fallback to async wait (main -> worker)
const waitFor = (isAsync, sb) => isAsync ?
                  (waitAsync || waitAsyncFallback)(sb, 0) :
                  (wait(sb, 0), {value: {then: fn => fn()}});

// retain buffers to transfer
const buffers = new WeakSet;

// retain either main threads or workers global context
const context = new WeakMap;

// used to generate a unique `id` per each worker `postMessage` "transaction"
let uid = 0;

/**
 * Create once a `Proxy` able to orchestrate synchronous `postMessage` out of the box.
 * @param {globalThis | Worker} self the context in which code should run
 * @param {{parse: (serialized: string) => any, stringify: (serializable: any) => string}} [JSON] an optional `JSON` like interface to `parse` or `stringify` content
 * @returns {ProxyHandler<globalThis> | ProxyHandler<Worker>}
 */
const coincident$1 = (self, {parse, stringify} = JSON) => {
  // create a Proxy once for the given context (globalThis or Worker instance)
  if (!context.has(self)) {
    // ensure the CHANNEL and data are posted correctly
    const post = (transfer, ...args) => self.postMessage({[CHANNEL]: args}, {transfer});

    context.set(self, new Proxy(new Map$1, {
      // there is very little point in checking prop in proxy for this very specific case
      // and I don't want to orchestrate a whole roundtrip neither, as stuff would fail
      // regardless if from Worker we access non existent Main callback, and vice-versa.
      // This is here mostly to guarantee that if such check is performed, at least the
      // get trap goes through and then it's up to developers guarantee they are accessing
      // stuff that actually exists elsewhere.
      has: (_, action) => typeof action === 'string' && !action.startsWith('_'),

      // worker related: get any utility that should be available on the main thread
      get: (_, action) => action === 'then' ? null : ((...args) => {
        // transaction id
        const id = uid++;

        // first contact: just ask for how big the buffer should be
        let sb = new Int32Array(new SharedArrayBuffer$1(I32_BYTES));

        // if a transfer list has been passed, drop it from args
        let transfer = [];
        if (buffers.has(args.at(-1) || transfer))
          buffers.delete(transfer = args.pop());

        // ask for invoke with arguments and wait for it
        post(transfer, id, sb, action, args);

        // helps deciding how to wait for results
        const isAsync = self instanceof Worker;
        return waitFor(isAsync, sb).value.then(() => {
          // commit transaction using the returned / needed buffer length
          const length = sb[0];

          // filter undefined results
          if (!length) return;

          // calculate the needed ui16 bytes length to store the result string
          const bytes = UI16_BYTES * length;

          // round up to the next amount of bytes divided by 4 to allow i32 operations
          sb = new Int32Array(new SharedArrayBuffer$1(bytes + (bytes % I32_BYTES)));

          // ask for results and wait for it
          post([], id, sb);
          return waitFor(isAsync, sb).value.then(
            // transform the shared buffer into a string and return it parsed
            () => parse(fromCharCode(...new Uint16Array(sb.buffer).slice(0, length)))
          );
        });
      }),

      // main thread related: react to any utility a worker is asking for
      set(actions, action, callback) {
        // lazy event listener and logic handling, triggered once by setters actions
        if (!actions.size) {
          // maps results by `id` as they are asked for
          const results = new Map$1;
          // add the event listener once (first defined setter, all others work the same)
          self.addEventListener('message', async (event) => {
            // grub the very same library CHANNEL; ignore otherwise
            const details = event.data?.[CHANNEL];
            if (isArray$2(details)) {
              // if early enough, avoid leaking data to other listeners
              event.stopImmediatePropagation();
              const [id, sb, ...rest] = details;
              // action available: it must be defined/known on the main thread
              if (rest.length) {
                const [action, args] = rest;
                if (actions.has(action)) {
                  // await for result either sync or async and serialize it
                  const result = stringify(await actions.get(action)(...args));
                  if (result) {
                    // store the result for "the very next" event listener call
                    results.set(id, result);
                    // communicate the required SharedArrayBuffer length out of the
                    // resulting serialized string
                    sb[0] = result.length;
                  }
                }
                // unknown action should be notified as missing on the main thread
                else {
                  throw new Error(`Unsupported action: ${action}`);
                }
              }
              // no action means: get results out of the well known `id`
              else {
                const result = results.get(id);
                results.delete(id);
                // populate the SharedArrayBuffer with utf-16 chars code
                for (let ui16a = new Uint16Array(sb.buffer), i = 0; i < result.length; i++)
                  ui16a[i] = result.charCodeAt(i);
              }
              // release te worker waiting either the length or the result
              notify(sb, 0);
            }
          });
        }
        // store this action callback allowing the setter in the process
        return !!actions.set(action, callback);
      }
    }));
  }
  return context.get(self);
};

coincident$1.transfer = (...args) => (buffers.add(args), args);

const OBJECT    = 'object';
const FUNCTION  = 'function';
const BOOLEAN   = 'boolean';
const NUMBER    = 'number';
const STRING    = 'string';
const UNDEFINED = 'undefined';
const BIGINT    = 'bigint';
const SYMBOL    = 'symbol';
const NULL      = 'null';

const {
  defineProperty: defineProperty$1,
  getOwnPropertyDescriptor,
  getPrototypeOf,
  isExtensible,
  ownKeys,
  preventExtensions,
  set,
  setPrototypeOf
} = Reflect;

const {assign: assign$1, create: create$1} = Object;

const TypedArray = getPrototypeOf(Int8Array);

const isArray$1 = 'isArray';

const augment = (descriptor, how) => {
  const {get, set, value} = descriptor;
  if (get) descriptor.get = how(get);
  if (set) descriptor.set = how(set);
  if (value) descriptor.value = how(value);
  return descriptor;
};

const entry = (type, value) => [type, value];

const asEntry = transform => value => {
  const type = typeof value;
  switch (type) {
    case OBJECT:
    if (value == null)
      return entry(NULL, value);
    if (value === globalThis)
      return entry(OBJECT, null);
    case FUNCTION:
      return transform(type, value);
    case BOOLEAN:
    case NUMBER:
    case STRING:
    case UNDEFINED:
    case BIGINT:
      return entry(type, value);
    case SYMBOL: {
      if (symbols.has(value))
        return entry(type, symbols.get(value));
    }
  }
  throw new Error(`Unable to handle this ${type} type`);
};

const symbols = new Map(
  ownKeys(Symbol)
    .filter(s => typeof Symbol[s] === SYMBOL)
    .map(s => [Symbol[s], s])
);
  
const symbol = value => {
  for (const [symbol, name] of symbols) {
    if (name === value)
      return symbol;
  }
};

function Bound() {
  return this;
}

const APPLY                        = 'apply';
const CONSTRUCT                    = 'construct';
const DEFINE_PROPERTY              = 'defineProperty';
const DELETE_PROPERTY              = 'deleteProperty';
const GET                          = 'get';
const GET_OWN_PROPERTY_DESCRIPTOR  = 'getOwnPropertyDescriptor';
const GET_PROTOTYPE_OF             = 'getPrototypeOf';
const HAS                          = 'has';
const IS_EXTENSIBLE                = 'isExtensible';
const OWN_KEYS                     = 'ownKeys';
const PREVENT_EXTENSION            = 'preventExtensions';
const SET                          = 'set';
const SET_PROTOTYPE_OF             = 'setPrototypeOf';
const DELETE                       = 'delete';

var main$1 = (name, patch) => {
  const eventsHandler = patch && new WeakMap;

  // patch once main UI tread
  if (patch) {
    const {addEventListener} = EventTarget.prototype;
    // this should never be on the way as it's extremely light and fast
    // but it's necessary to allow "preventDefault" or other event invokes at distance
    defineProperty$1(EventTarget.prototype, 'addEventListener', {
      value(type, listener, ...options) {
        if (options.at(0)?.invoke) {
          if (!eventsHandler.has(this))
            eventsHandler.set(this, new Map);
          eventsHandler.get(this).set(type, [].concat(options[0].invoke));
          delete options[0].invoke;
        }
        return addEventListener.call(this, type, listener, ...options);
      }
    });
  }

  const handleEvent = patch && (event => {
    const {currentTarget, target, type} = event;
    for (const method of eventsHandler.get(currentTarget || target)?.get(type) || [])
      event[method]();
  });

  return (thread, MAIN, THREAD, ...args) => {
    let id = 0;
    const ids = new Map;
    const values = new Map;

    const {[THREAD]: __thread__} = thread;

    const global = args.length ? assign$1(create$1(globalThis), ...args) : globalThis;

    const result = asEntry((type, value) => {
      if (!ids.has(value)) {
        let sid;
        // a bit apocalyptic scenario but if this main runs forever
        // and the id does a whole int32 roundtrip we might have still
        // some reference danglign around
        while (values.has(sid = id++));
        ids.set(value, sid);
        values.set(sid, value);
      }
      return entry(type, ids.get(value));
    });

    const registry = new FinalizationRegistry(id => {
      __thread__(DELETE, entry(STRING, id));
    });

    const target = ([type, value]) => {
      switch (type) {
        case OBJECT:
          if (value == null)
            return global;
          if (typeof value === NUMBER)
            return values.get(value);
          if (!(value instanceof TypedArray)) {
            for (const key in value)
              value[key] = target(value[key]);
          }
          return value;
        case FUNCTION:
          if (typeof value === STRING) {
            if (!values.has(value)) {
              const cb = function (...args) {
                if (patch && args.at(0) instanceof Event) handleEvent(...args);
                return __thread__(
                  APPLY,
                  entry(FUNCTION, value),
                  result(this),
                  args.map(result)
                );
              };
              const ref = new WeakRef(cb);
              values.set(value, ref);
              registry.register(cb, value, ref);
            }
            return values.get(value).deref();
          }
          return values.get(value);
        case SYMBOL:
          return symbol(value);
      }
      return value;
    };

    const trapsHandler = {
      [APPLY]: (target, thisArg, args) => result(target.apply(thisArg, args)),
      [CONSTRUCT]: (target, args) => result(new target(...args)),
      [DEFINE_PROPERTY]: (target, name, descriptor) => result(defineProperty$1(target, name, descriptor)),
      [DELETE_PROPERTY]: (target, name) => result(delete target[name]),
      [GET_PROTOTYPE_OF]: target => result(getPrototypeOf(target)),
      [GET]: (target, name) => result(target[name]),
      [GET_OWN_PROPERTY_DESCRIPTOR]: (target, name) => {
        const descriptor = getOwnPropertyDescriptor(target, name);
        return descriptor ? entry(OBJECT, augment(descriptor, result)) : entry(UNDEFINED, descriptor);
      },
      [HAS]: (target, name) => result(name in target),
      [IS_EXTENSIBLE]: target => result(isExtensible(target)),
      [OWN_KEYS]: target => entry(OBJECT, ownKeys(target).map(result)),
      [PREVENT_EXTENSION]: target => result(preventExtensions(target)),
      [SET]: (target, name, value) => result(set(target, name, value)),
      [SET_PROTOTYPE_OF]: (target, proto) => result(setPrototypeOf(target, proto)),
      [DELETE](id) {
        ids.delete(values.get(id));
        values.delete(id);
      }
    };

    thread[MAIN] = (trap, entry, ...args) => {
      switch (trap) {
        case APPLY:
          args[0] = target(args[0]);
          args[1] = args[1].map(target);
          break;
        case CONSTRUCT:
          args[0] = args[0].map(target);
          break;
        case DEFINE_PROPERTY: {
          const [name, descriptor] = args;
          args[0] = target(name);
          const {get, set, value} = descriptor;
          if (get) descriptor.get = target(get);
          if (set) descriptor.set = target(set);
          if (value) descriptor.value = target(value);
          break;
        }
        default:
          args = args.map(target);
          break;
      }
      return trapsHandler[trap](target(entry), ...args);
    };

    return {
      proxy: thread,
      [name.toLowerCase()]: global,
      [`is${name}Proxy`]: () => false
    };
  };
};

var main = main$1('Window', true);

var thread$1 = name => {
  let id = 0;
  const ids = new Map;
  const values = new Map;

  const __proxied__ = Symbol();

  const bound = target => typeof target === FUNCTION ? target() : target;

  const isProxy = value => typeof value === OBJECT && !!value && __proxied__ in value;

  const localArray = Array[isArray$1];

  const argument = asEntry(
    (type, value) => {
      if (__proxied__ in value)
        return bound(value[__proxied__]);
      if (type === FUNCTION) {
        if (!values.has(value)) {
          let sid;
          // a bit apocalyptic scenario but if this thread runs forever
          // and the id does a whole int32 roundtrip we might have still
          // some reference dangling around
          while (values.has(sid = String(id++)));
          ids.set(value, sid);
          values.set(sid, value);
        }
        return entry(type, ids.get(value));
      }
      if (!(value instanceof TypedArray)) {
        for(const key in value)
          value[key] = argument(value[key]);
      }
      return entry(type, value);
    }
  );

  return (main, MAIN, THREAD) => {
    const { [MAIN]: __main__ } = main;

    const proxies = new Map;

    const registry = new FinalizationRegistry(id => {
      proxies.delete(id);
      __main__(DELETE, argument(id));
    });

    const register = (entry) => {
      const [type, value] = entry;
      if (!proxies.has(value)) {
        const target = type === FUNCTION ? Bound.bind(entry) : entry;
        const proxy = new Proxy(target, proxyHandler);
        const ref = new WeakRef(proxy);
        proxies.set(value, ref);
        registry.register(proxy, value, ref);
      }
      return proxies.get(value).deref();
    };

    const fromEntry = entry => {
      const [type, value] = entry;
      switch (type) {
        case OBJECT:
          return value === null ? globalThis : (
            typeof value === NUMBER ? register(entry) : value
          );
        case FUNCTION:
          return typeof value === STRING ? values.get(value) : register(entry);
        case SYMBOL:
          return symbol(value);
      }
      return value;
    };

    const result = (TRAP, target, ...args) => fromEntry(__main__(TRAP, bound(target), ...args));

    const proxyHandler = {
      [APPLY]: (target, thisArg, args) => {
        // Nicholas + Damien
        if (thisArg?.[0] === globalThis) {
          // debugger;
          console.log('LEAKED SCOPE');
          console.log(thisArg);
        }
        // TODO please remove this ASAP as it makes literally no sense in this repo.
        // see MicroPython bug: https://github.com/micropython/micropython/issues/11995
        const context = thisArg?.[0] === globalThis ? globalThis : thisArg;
        return result(APPLY, target, argument(context), args.map(argument));
      },
      [CONSTRUCT]: (target, args) => result(CONSTRUCT, target, args.map(argument)),
      [DEFINE_PROPERTY]: (target, name, descriptor) => {
        const { get, set, value } = descriptor;
        if (typeof get === FUNCTION) descriptor.get = argument(get);
        if (typeof set === FUNCTION) descriptor.set = argument(set);
        if (typeof value === FUNCTION) descriptor.value = argument(value);
        return result(DEFINE_PROPERTY, target, argument(name), descriptor);
      },
      [DELETE_PROPERTY]: (target, name) => result(DELETE_PROPERTY, target, argument(name)),
      [GET_PROTOTYPE_OF]: target => result(GET_PROTOTYPE_OF, target),
      [GET]: (target, name) => name === __proxied__ ? target : result(GET, target, argument(name)),
      [GET_OWN_PROPERTY_DESCRIPTOR]: (target, name) => {
        const descriptor = result(GET_OWN_PROPERTY_DESCRIPTOR, target, argument(name));
        return descriptor && augment(descriptor, fromEntry);
      },
      [HAS]: (target, name) => name === __proxied__ || result(HAS, target, argument(name)),
      [IS_EXTENSIBLE]: target => result(IS_EXTENSIBLE, target),
      [OWN_KEYS]: target => result(OWN_KEYS, target).map(fromEntry),
      [PREVENT_EXTENSION]: target => result(PREVENT_EXTENSION, target),
      [SET]: (target, name, value) => result(SET, target, argument(name), argument(value)),
      [SET_PROTOTYPE_OF]: (target, proto) => result(SET_PROTOTYPE_OF, target, argument(proto)),
    };

    main[THREAD] = (trap, entry, ctx, args) => {
      switch (trap) {
        case APPLY:
          return fromEntry(entry).apply(fromEntry(ctx), args.map(fromEntry));
        case DELETE: {
          const id = fromEntry(entry);
          ids.delete(values.get(id));
          values.delete(id);
        }
      }
    };

    const global = new Proxy([OBJECT, null], proxyHandler);

    // this is needed to avoid confusion when new Proxy([type, value])
    // passes through `isArray` check, as that would return always true
    // by specs and there's no Proxy trap to avoid it.
    const remoteArray = global.Array[isArray$1];
    defineProperty$1(Array, isArray$1, {
      value: ref => isProxy(ref) ? remoteArray(ref) : localArray(ref)
    });

    return {
      [name.toLowerCase()]: global,
      [`is${name}Proxy`]: isProxy,
      proxy: main
    };
  };
};

var thread = thread$1('Window');

const proxies = new WeakMap;

/**
 * @typedef {object} Coincident
 * @property {ProxyHandler<globalThis>} proxy
 * @property {ProxyHandler<Window>} window
 * @property {(value: any) => boolean} isWindowProxy
 */

/**
 * Create once a `Proxy` able to orchestrate synchronous `postMessage` out of the box.
 * In workers, returns a `{proxy, window, isWindowProxy}` namespace to reach main globals synchronously.
 * @param {Worker | globalThis} self the context in which code should run
 * @returns {ProxyHandler<Worker> | Coincident}
 */
const coincident = (self, ...args) => {
  const proxy = coincident$1(self, ...args);
  if (!proxies.has(proxy)) {
    const util = self instanceof Worker ? main : thread;
    proxies.set(proxy, util(proxy, MAIN, THREAD));
  }
  return proxies.get(proxy);
};

coincident.transfer = coincident$1.transfer;

const { isArray } = Array;

const { assign, create, defineProperties, defineProperty, entries } = Object;

const { all, resolve: resolve$1 } = new Proxy(Promise, {
    get: ($, name) => $[name].bind($),
});

const absoluteURL = (path, base = location.href) => new URL(path, base).href;

Promise.withResolvers || (Promise.withResolvers = function withResolvers() {
  var a, b, c = new this(function (resolve, reject) {
    a = resolve;
    b = reject;
  });
  return {resolve: a, reject: b, promise: c};
});

/** @param {Response} response */
const getBuffer = (response) => response.arrayBuffer();

/** @param {Response} response */
const getJSON = (response) => response.json();

/** @param {Response} response */
const getText = (response) => response.text();

/**
 * Trim code only if it's a single line that prettier or other tools might have modified.
 * @param {string} code code that might be a single line
 * @returns {string}
 */
const clean = (code) =>
    code.replace(/^[^\r\n]+$/, (line) => line.trim());

// REQUIRES INTEGRATION TEST
/* c8 ignore start */
const io = new WeakMap();
const stdio = (init) => {
    const context = init || console;
    const localIO = {
        stderr: (context.stderr || console.error).bind(context),
        stdout: (context.stdout || console.log).bind(context),
    };
    return {
        stderr: (...args) => localIO.stderr(...args),
        stdout: (...args) => localIO.stdout(...args),
        async get(engine) {
            const interpreter = await engine;
            io.set(interpreter, localIO);
            return interpreter;
        },
    };
};
/* c8 ignore stop */

// This should be the only helper needed for all Emscripten based FS exports
const writeFile$1 = (FS, path, buffer) => {
    const { parentPath, name } = FS.analyzePath(path, true);
    FS.mkdirTree(parentPath);
    return FS.writeFile([parentPath, name].join("/"), new Uint8Array(buffer), {
        canOwn: true,
    });
};

// This is instead a fallback for Lua or others
const writeFileShim = (FS, path, buffer) => {
    path = resolve(FS, path);
    mkdirTree(FS, dirname(path));
    return FS.writeFile(path, new Uint8Array(buffer), { canOwn: true });
};

const dirname = (path) => {
    const tree = path.split("/");
    tree.pop();
    return tree.join("/");
};

const mkdirTree = (FS, path) => {
    const current = [];
    for (const branch of path.split("/")) {
        current.push(branch);
        if (branch) FS.mkdir(current.join("/"));
    }
};

const resolve = (FS, path) => {
    const tree = [];
    for (const branch of path.split("/")) {
        switch (branch) {
            case "":
                break;
            case ".":
                break;
            case "..":
                tree.pop();
                break;
            default:
                tree.push(branch);
        }
    }
    return [FS.cwd()].concat(tree).join("/").replace(/^\/+/, "/");
};

const calculateFetchPaths = (config_fetch) => {
    // REQUIRES INTEGRATION TEST
    /* c8 ignore start */
    for (const { files, to_file, from = "" } of config_fetch) {
        if (files !== undefined && to_file !== undefined)
            throw new Error(
                `Cannot use 'to_file' and 'files' parameters together!`,
            );
        if (files === undefined && to_file === undefined && from.endsWith("/"))
            throw new Error(
                `Couldn't determine the filename from the path ${from}, please supply 'to_file' parameter.`,
            );
    }
    /* c8 ignore stop */
    return config_fetch.flatMap(
        ({ from = "", to_folder = ".", to_file, files }) => {
            if (isArray(files))
                return files.map((file) => ({
                    url: joinPaths([from, file]),
                    path: joinPaths([to_folder, file]),
                }));
            const filename = to_file || from.slice(1 + from.lastIndexOf("/"));
            return [{ url: from, path: joinPaths([to_folder, filename]) }];
        },
    );
};

const joinPaths = (parts) => {
    const res = parts
        .map((part) => part.trim().replace(/(^[/]*|[/]*$)/g, ""))
        .filter((p) => p !== "" && p !== ".")
        .join("/");

    return parts[0].startsWith("/") ? `/${res}` : res;
};

const fetchResolved = (config_fetch, url) =>
    fetch(absoluteURL(url, base.get(config_fetch)));

const base = new WeakMap();

const fetchPaths = (module, interpreter, config_fetch) =>
    all(
        calculateFetchPaths(config_fetch).map(({ url, path }) =>
            fetchResolved(config_fetch, url)
                .then(getBuffer)
                .then((buffer) => module.writeFile(interpreter, path, buffer)),
        ),
    );
/* c8 ignore stop */

// REQUIRES INTEGRATION TEST
/* c8 ignore start */
const registerJSModule = (interpreter, name, value) => {
    interpreter.registerJsModule(name, value);
};

const run = (interpreter, code) => interpreter.runPython(clean(code));

const runAsync = (interpreter, code) =>
    interpreter.runPythonAsync(clean(code));

const runEvent$1 = async (interpreter, code, event) => {
    // allows method(event) as well as namespace.method(event)
    // it does not allow fancy brackets names for now
    const [name, ...keys] = code.split(".");
    let target = interpreter.globals.get(name);
    let context;
    for (const key of keys) [context, target] = [target, target[key]];
    await target.call(context, event);
};

const writeFile = ({ FS }, path, buffer) =>
    writeFile$1(FS, path, buffer);
/* c8 ignore stop */

const type$3 = "micropython";

// REQUIRES INTEGRATION TEST
/* c8 ignore start */
var micropython = {
    type: type$3,
    module: () => `/micropython.mjs`,
    async engine({ loadMicroPython }, config, url) {
        const { stderr, stdout, get } = stdio();
        url = url.replace(/\.m?js$/, ".wasm");
        const interpreter = await get(loadMicroPython({ stderr, stdout, url }));
        if (config.fetch) await fetchPaths(this, interpreter, config.fetch);
        return interpreter;
    },
    registerJSModule,
    run,
    runAsync,
    runEvent: runEvent$1,
    writeFile,
};
/* c8 ignore stop */

const type$2 = "pyodide";

// REQUIRES INTEGRATION TEST
/* c8 ignore start */
var pyodide = {
    type: type$2,
    module: (version = "0.23.2") =>
        `https://cdn.jsdelivr.net/pyodide/v${version}/full/pyodide.mjs`,
    async engine({ loadPyodide }, config, url) {
        const { stderr, stdout, get } = stdio();
        const indexURL = url.slice(0, url.lastIndexOf("/"));
        const interpreter = await get(
            loadPyodide({ stderr, stdout, indexURL }),
        );
        if (config.fetch) await fetchPaths(this, interpreter, config.fetch);
        if (config.packages) {
            await interpreter.loadPackage("micropip");
            const micropip = await interpreter.pyimport("micropip");
            await micropip.install(config.packages);
            micropip.destroy();
        }
        return interpreter;
    },
    registerJSModule,
    run,
    runAsync,
    runEvent: runEvent$1,
    writeFile,
};
/* c8 ignore stop */

const type$1 = "ruby-wasm-wasi";
const jsType = type$1.replace(/\W+/g, "_");

// MISSING:
//  * there is no VFS apparently or I couldn't reach any
//  * I've no idea how to override the stderr and stdout
//  * I've no idea how to import packages

// REQUIRES INTEGRATION TEST
/* c8 ignore start */
var ruby_wasm_wasi = {
    type: type$1,
    experimental: true,
    module: (version = "2.0.0") =>
        `https://cdn.jsdelivr.net/npm/ruby-3_2-wasm-wasi@${version}/dist/browser.esm.js`,
    async engine({ DefaultRubyVM }, config, url) {
        const response = await fetch(
            `${url.slice(0, url.lastIndexOf("/"))}/ruby.wasm`,
        );
        const module = await WebAssembly.compile(await response.arrayBuffer());
        const { vm: interpreter } = await DefaultRubyVM(module);
        if (config.fetch) await fetchPaths(this, interpreter, config.fetch);
        return interpreter;
    },
    // Fallback to globally defined module fields (i.e. $xworker)
    registerJSModule(interpreter, _, value) {
        const code = ['require "js"'];
        for (const [k, v] of entries(value)) {
            const id = `__module_${jsType}_${k}`;
            globalThis[id] = v;
            code.push(`$${k}=JS.global[:${id}]`);
        }
        this.run(interpreter, code.join(";"));
    },
    run: (interpreter, code) => interpreter.eval(clean(code)),
    runAsync: (interpreter, code) => interpreter.evalAsync(clean(code)),
    async runEvent(interpreter, code, event) {
        // patch common xworker.onmessage/onerror cases
        if (/^xworker\.(on\w+)$/.test(code)) {
            const { $1: name } = RegExp;
            const id = `__module_${jsType}_event`;
            globalThis[id] = event;
            this.run(
                interpreter,
                `require "js";$xworker.call("${name}",JS.global[:${id}])`,
            );
            delete globalThis[id];
        } else {
            // Experimental: allows only events by fully qualified method name
            const method = this.run(interpreter, `method(:${code})`);
            await method.call(code, interpreter.wrap(event));
        }
    },
    writeFile: () => {
        throw new Error(`writeFile is not supported in ${type$1}`);
    },
};
/* c8 ignore stop */

const type = "wasmoon";

// MISSING:
//  * I've no idea how to import packages

// REQUIRES INTEGRATION TEST
/* c8 ignore start */
var wasmoon = {
    type,
    module: (version = "1.15.0") =>
        `https://cdn.jsdelivr.net/npm/wasmoon@${version}/+esm`,
    async engine({ LuaFactory, LuaLibraries }, config) {
        const { stderr, stdout, get } = stdio();
        const interpreter = await get(new LuaFactory().createEngine());
        interpreter.global.getTable(LuaLibraries.Base, (index) => {
            interpreter.global.setField(index, "print", stdout);
            interpreter.global.setField(index, "printErr", stderr);
        });
        if (config.fetch) await fetchPaths(this, interpreter, config.fetch);
        return interpreter;
    },
    // Fallback to globally defined module fields
    registerJSModule: (interpreter, _, value) => {
        for (const [k, v] of entries(value)) interpreter.global.set(k, v);
    },
    run: (interpreter, code) => interpreter.doStringSync(clean(code)),
    runAsync: (interpreter, code) => interpreter.doString(clean(code)),
    runEvent: async (interpreter, code, event) => {
        // allows method(event) as well as namespace.method(event)
        // it does not allow fancy brackets names for now
        const [name, ...keys] = code.split(".");
        let target = interpreter.global.get(name);
        let context;
        for (const key of keys) [context, target] = [target, target[key]];
        await target.call(context, event);
    },
    writeFile: (
        {
            cmodule: {
                module: { FS },
            },
        },
        path,
        buffer,
    ) => writeFileShim(FS, path, buffer),
};
/* c8 ignore stop */

// ⚠️ Part of this file is automatically generated
//    The :RUNTIMES comment is a delimiter and no code should be written/changed after
//    See rollup/build_interpreters.cjs to know more


/** @type {Map<string, object>} */
const registry = new Map();

/** @type {Map<string, object>} */
const configs = new Map();

const interpreter$1 = new Proxy(new Map(), {
    get(map, id) {
        if (!map.has(id)) {
            const [type, ...rest] = id.split("@");
            const interpreter = registry.get(type);
            const url = /^https?:\/\//i.test(rest)
                ? rest.join("@")
                : interpreter.module(...rest);
            map.set(id, {
                url,
                module: import(url),
                engine: interpreter.engine.bind(interpreter),
            });
        }
        const { url, module, engine } = map.get(id);
        return (config, baseURL) =>
            module.then((module) => {
                configs.set(id, config);
                const fetch = config?.fetch;
                if (fetch) base.set(fetch, baseURL);
                return engine(module, config, url);
            });
    },
});

const register = (interpreter) => {
    for (const type of [].concat(interpreter.type)) {
        registry.set(type, interpreter);
    }
};
for (const interpreter of [micropython, pyodide, ruby_wasm_wasi, wasmoon])
    register(interpreter);

// lazy TOML parser (fast-toml might be a better alternative)
const TOML_LIB = `https://cdn.jsdelivr.net/npm/basic-toml@0.3.1/es.js`;

/**
 * @param {string} text TOML text to parse
 * @returns {object} the resulting JS object
 */
const parse = async (text) => (await import(TOML_LIB)).parse(text);

/**
 * @param {string} id the interpreter name @ version identifier
 * @param {string} [config] optional config file to parse
 * @returns
 */
const getRuntime = (id, config) => {
    let options = {};
    if (config) {
        // REQUIRES INTEGRATION TEST
        /* c8 ignore start */
        if (config.endsWith(".json")) {
            options = fetch(config).then(getJSON);
        } else if (config.endsWith(".toml")) {
            options = fetch(config).then(getText).then(parse);
        } else {
            try {
                options = JSON.parse(config);
            } catch (_) {
                options = parse(config);
            }
            // make the config a URL to be able to retrieve relative paths from it
            config = absoluteURL("./config.txt");
        }
        /* c8 ignore stop */
    }
    return resolve$1(options).then((options) => interpreter$1[id](options, config));
};

/**
 * @param {string} type the interpreter type
 * @param {string} [version] the optional interpreter version
 * @returns
 */
const getRuntimeID = (type, version = "") =>
    `${type}@${version}`.replace(/@$/, "");

// ⚠️ This file is used to generate xworker.js
//    That means if any import is circular or brings in too much
//    that would be a higher payload for every worker.
//    Please check via `npm run size` that worker code is not much
//    bigger than it used to be before any changes is applied to this file.


// bails out out of the box with a native/meaningful error
// in case the SharedArrayBuffer is not available
try {
    new SharedArrayBuffer(4);
} catch (_) {
    throw new Error(
        [
            "Unable to use SharedArrayBuffer due insecure environment.",
            "Please read requirements in MDN: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SharedArrayBuffer#security_requirements",
        ].join("\n"),
    );
}

let interpreter, runEvent;
const add = (type, fn) => {
    addEventListener(
        type,
        fn ||
            (async (event) => {
                await interpreter;
                runEvent(`xworker.on${type}`, event);
            }),
        !!fn && { once: true },
    );
};

const { proxy: sync, window, isWindowProxy } = coincident(self, JSON);

const xworker = {
    // allows synchronous utilities between this worker and the main thread
    sync,
    // allow access to the main thread world
    window,
    // allow introspection for foreign (main thread) refrences
    isWindowProxy,
    // standard worker related events / features
    onerror() {},
    onmessage() {},
    onmessageerror() {},
    postMessage: postMessage.bind(self),
};

add("message", ({ data: { options, code, hooks } }) => {
    interpreter = (async () => {
        const { type, version, config, async: isAsync } = options;
        const interpreter = await getRuntime(
            getRuntimeID(type, version),
            config,
        );
        const details = create(registry.get(type));
        const name = `run${isAsync ? "Async" : ""}`;

        if (hooks) {
            // patch code if needed
            const { beforeRun, beforeRunAsync, afterRun, afterRunAsync } =
                hooks;

            const after = afterRun || afterRunAsync;
            const before = beforeRun || beforeRunAsync;

            // append code that should be executed *after* first
            if (after) {
                const method = details[name].bind(details);
                details[name] = (interpreter, code) =>
                    method(interpreter, `${code}\n${after}`);
            }

            // prepend code that should be executed *before* (so that after is post-patched)
            if (before) {
                const method = details[name].bind(details);
                details[name] = (interpreter, code) =>
                    method(interpreter, `${before}\n${code}`);
            }
        }
        // set the `xworker` global reference once
        details.registerJSModule(interpreter, "xworker", { xworker });
        // simplify runEvent calls
        runEvent = details.runEvent.bind(details, interpreter);
        // run either sync or async code in the worker
        await details[name](interpreter, code);
        return interpreter;
    })();
    add("error");
    add("message");
    add("messageerror");
});
